# Celery With Django

Celery with Django for backend process
