from django.apps import AppConfig


class CeleryappConfig(AppConfig):
    name = 'CeleryApp'
