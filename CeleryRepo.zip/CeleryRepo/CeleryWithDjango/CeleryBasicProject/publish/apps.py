from django.apps import AppConfig


class PublishConfig(AppConfig):
    name = 'publish'
